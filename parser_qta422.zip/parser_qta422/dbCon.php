<?php
	$parser_key = ['parser', '9823YH)(*', 'prototype'];
	$logger_key = ['logger', '*(HI*(ye0(', 'sys_log'];
?>